export class CreateRefralDto {}
