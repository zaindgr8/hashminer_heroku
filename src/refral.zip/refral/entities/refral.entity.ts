export class Refral {}
