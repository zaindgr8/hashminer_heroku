import { Injectable } from '@nestjs/common';
import { CreateRefralDto } from './dto/create-refral.dto';
import { UpdateRefralDto } from './dto/update-refral.dto';
import { Model } from 'mongoose';
import { User } from '../user/entities/user.entity';
import { Package } from '../packages/entities/package.entity';
import { UserPackage } from '../packages/entities/user_packages.entity';
import { InjectModel } from '@nestjs/mongoose';
import * as crypto from 'crypto';

@Injectable()
export class RefralService {

  constructor(
    @InjectModel(User.name) private readonly userModel: Model<User>,
     
  ) {}
  create(createRefralDto: CreateRefralDto) {
    return 'This action adds a new refral';
  }

  async getrefral(userId:string) {
    // return `This action returns all refral`;
    try {
      const user = await this.userModel.findById(userId);
      console.log('user', user);
// Your object
      const referrals:any = { father: user._id, grandfather: user?.father };
      const encryptionKey = 'your-secret-key';

      // Encryption function
function encryptObject(obj, key) {
  const jsonString = JSON.stringify(obj);
  const cipher = crypto.createCipher('aes-128-cbc', key);
  let encryptedData = cipher.update(jsonString, 'utf-8', 'hex');
  encryptedData += cipher.final('hex');
  return encryptedData;
}

// Encrypt the object
const encryptedString = encryptObject(referrals, encryptionKey);
console.log('Encrypted String:', encryptedString);
      if (!user) {
        throw new Error('User not found');
      }

// // Decryption function
// function decryptString(encryptedString, key) {
//   const decipher = createDecipher('aes-256-cbc', key);
//   let decryptedData = decipher.update(encryptedString, 'hex', 'utf-8');
//   decryptedData += decipher.final('utf-8');
//   return decryptedData;
// }
         const result = {link: encryptedString};
         console.log("result", result)
        return  result
      // user.status = 'pending';
      // return await user.save();
    } catch (error) {
      console.error('Error updating user status:', error.message);
      throw error;
    }
  }

  findOne(id: number) {
    return `This action returns a #${id} refral`;
  }

  update(id: number, updateRefralDto: UpdateRefralDto) {
    return `This action updates a #${id} refral`;
  }

  remove(id: number) {
    return `This action removes a #${id} refral`;
  }
}
